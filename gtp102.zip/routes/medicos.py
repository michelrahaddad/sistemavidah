
from flask import Blueprint, render_template, redirect, url_for, flash
from utils.forms import MedicoForm
from utils.db import get_db_connection
from werkzeug.security import generate_password_hash

medicos_bp = Blueprint('medicos', __name__)

@medicos_bp.route('/cadastrar_medico', methods=['GET', 'POST'])
def cadastrar_medico():
    form = MedicoForm()
    if form.validate_on_submit():
        nome = form.nome.data
        crm = form.crm.data
        senha = form.senha.data
        conn = get_db_connection()
        existente = conn.execute("SELECT * FROM medicos WHERE crm = ?", (crm,)).fetchone()
        if existente:
            flash('CRM já cadastrado!', 'erro')
            conn.close()
            return render_template('cadastro_medico.html', form=form)
        senha_hash = generate_password_hash(senha)
        conn.execute("INSERT INTO medicos (nome, crm, senha) VALUES (?, ?, ?)", (nome, crm, senha_hash))
        conn.commit()
        conn.close()
        flash('Médico cadastrado com sucesso!', 'sucesso')
        return redirect(url_for('auth.login'))
    return render_template('cadastro_medico.html', form=form)
