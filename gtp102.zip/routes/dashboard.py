
from flask import Blueprint, render_template, session, redirect, url_for
import sqlite3

dashboard_bp = Blueprint('dashboard', __name__)

def get_db_connection():
    conn = sqlite3.connect('dados.db')
    conn.row_factory = sqlite3.Row
    return conn

@dashboard_bp.route('/dashboard')
def dashboard():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    conn = get_db_connection()
    total_pacientes = conn.execute('SELECT COUNT(*) FROM pacientes').fetchone()[0]
    total_receitas = conn.execute('SELECT COUNT(*) FROM receitas').fetchone()[0]
    total_exames = conn.execute('SELECT COUNT(*) FROM exames_lab').fetchone()[0]
    conn.close()

    return render_template('dashboard.html',
                           total_pacientes=total_pacientes,
                           total_receitas=total_receitas,
                           total_exames=total_exames)
