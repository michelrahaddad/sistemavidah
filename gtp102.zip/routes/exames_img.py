
from flask import Blueprint, render_template, request, redirect, url_for, session, send_file
from utils.db import get_db_connection
from datetime import datetime
import io

exames_img_bp = Blueprint('exames_img', __name__)

@exames_img_bp.route('/exames_img', methods=['GET'])
def exames_img():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))
    conn = get_db_connection()
    pacientes = conn.execute("SELECT * FROM pacientes").fetchall()
    conn.close()
    return render_template('exames_img.html', pacientes=pacientes)

@exames_img_bp.route('/salvar_exames_img', methods=['POST'])
def salvar_exames_img():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    data = datetime.now().strftime('%Y-%m-%d')
    nome_paciente = request.form['nome_paciente'].strip()
    exames = request.form.getlist('exame[]')

    if not nome_paciente:
        flash('Nome do paciente é obrigatório.', 'error')
        return redirect(url_for('exames_img.exames_img'))

    if not exames:
        flash('Selecione pelo menos um exame de imagem.', 'error')
        return redirect(url_for('exames_img.exames_img'))

    exames = request.form.getlist('exame[]')

    conn = get_db_connection()
    medico = conn.execute("SELECT nome, crm FROM medicos WHERE id = ?", (session['usuario']['id'],)).fetchone()
    paciente = conn.execute("SELECT id FROM pacientes WHERE nome = ?", (nome_paciente,)).fetchone()

    conn.execute(
        "INSERT INTO exames_img (nome_paciente, exames, medico, data, id_paciente, id_medico) VALUES (?, ?, ?, ?, ?, ?)",
        (
            nome_paciente,
            ','.join(exames),
            medico['nome'],
            data,
            paciente['id'] if paciente else None,
            session['usuario']['id']
        )
    )
    exame_id = conn.execute("SELECT last_insert_rowid()").fetchone()[0]

    conn.execute(
        "INSERT INTO prontuario (tipo, id_registro, id_paciente, id_medico, data) VALUES (?, ?, ?, ?, ?)",
        ('exame_img', exame_id, paciente['id'] if paciente else None, session['usuario']['id'], data)
    )

    conn.commit()
    conn.close()

    rendered = render_template('exames_img_pdf.html', nome_paciente=nome_paciente, exames=exames,
                               medico=medico['nome'], crm=medico['crm'], data=data)

    return send_file(io.BytesIO(pdf_file), download_name='exames_imagem.pdf', as_attachment=True)

@exames_img_bp.route('/refazer/exame_img/<int:id>', methods=['GET'])
def refazer_exame_img(id):
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))
    conn = get_db_connection()
    exame = conn.execute("SELECT * FROM exames_img WHERE id = ?", (id,)).fetchone()
    conn.close()

    exames = exame['exames'].split(',')

    return render_template('exames_img.html',
                           nome_paciente=exame['nome_paciente'],
                           exames=exames,
                           refazer=True)
