
from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from utils.forms import LoginForm
from utils.db import get_db_connection
from werkzeug.security import check_password_hash

auth_bp = Blueprint('auth', __name__)

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    form = LoginForm()
    if form.validate_on_submit():
        nome = form.nome.data
        crm = form.crm.data
        senha = form.senha.data
        conn = get_db_connection()
        medico = conn.execute("SELECT * FROM medicos WHERE nome = ? AND crm = ?", (nome, crm)).fetchone()
        conn.close()
        if medico and check_password_hash(medico['senha'], senha):
            session['usuario'] = dict(medico)
            return redirect(url_for('dashboard.dashboard'))
        else:
            flash('Credenciais inválidas.')
    return render_template('login.html', form=form)

@auth_bp.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('auth.login'))
