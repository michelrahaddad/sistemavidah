
from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, SubmitField
from wtforms.validators import DataRequired

class LoginForm(FlaskForm):
    nome = StringField('Nome', validators=[DataRequired()])
    crm = StringField('CRM', validators=[DataRequired()])
    senha = PasswordField('Senha', validators=[DataRequired()])
    submit = SubmitField('Entrar')

class MedicoForm(FlaskForm):
    nome = StringField('Nome', validators=[DataRequired()])
    crm = StringField('CRM', validators=[DataRequired()])
    senha = PasswordField('Senha', validators=[DataRequired()])
    submit = SubmitField('Cadastrar')


from datetime import datetime

def validar_data(data_str):
    try:
        datetime.strptime(data_str, '%Y-%m-%d')
        return True
    except ValueError:
        return False

def sanitizar_entrada(texto):
    return texto.strip() if texto else ""


import re

def validar_crm(crm):
    pattern = r'^\d{4,6}/[A-Z]{2}$'
    return bool(re.match(pattern, crm))


import shutil
from datetime import datetime

def backup_database():
    backup_name = f"backup_dados_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
    shutil.copy2('dados.db', f'backups/{backup_name}')
