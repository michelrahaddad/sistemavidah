from flask import Blueprint, render_template, request, redirect, url_for, session, flash
from utils.db import get_db_connection
from datetime import datetime

agenda_bp = Blueprint('agenda', __name__)

@agenda_bp.route('/agenda', methods=['GET', 'POST'])
def agenda():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    conn = get_db_connection()

    if request.method == 'POST':
        data = request.form['data'].strip()
        paciente = request.form['paciente'].strip()

        if not paciente or not data:
            flash('Preencha o nome do paciente e a data.', 'error')
            return redirect(url_for('agenda.agenda'))

        motivo = request.form['motivo']
        paciente_id = conn.execute("SELECT id FROM pacientes WHERE nome = ?", (paciente,)).fetchone()

        conn.execute(
            "INSERT INTO agenda (data, paciente, motivo, id_paciente, id_medico) VALUES (?, ?, ?, ?, ?)",
            (data, paciente, motivo, paciente_id['id'] if paciente_id else None, session['usuario']['id'])
        )
        conn.commit()

    filtro_data = request.args.get('data')
    if filtro_data:
        agendamentos = conn.execute("SELECT * FROM agenda WHERE data = ?", (filtro_data,)).fetchall()
    else:
        agendamentos = conn.execute("SELECT * FROM agenda ORDER BY data DESC LIMIT 30").fetchall()

    conn.close()
    return render_template('agenda.html', agendamentos=agendamentos)

@agenda_bp.route('/agenda/excluir/<int:id>', methods=['GET'])
def excluir_agendamento(id):
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    conn = get_db_connection()
    conn.execute("DELETE FROM agenda WHERE id = ?", (id,))
    conn.commit()
    conn.close()
    return redirect(url_for('agenda.agenda'))

@agenda_bp.route('/agenda/editar/<int:id>', methods=['POST'])
def editar_agendamento(id):
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    data = request.form['data'].strip()
    paciente = request.form['paciente'].strip()

    if not paciente or not data:
        flash('Preencha o nome do paciente e a data.', 'error')
        return redirect(url_for('agenda.agenda'))

    motivo = request.form['motivo']

    conn = get_db_connection()
    conn.execute("UPDATE agenda SET data = ?, paciente = ?, motivo = ? WHERE id = ?",
                 (data, paciente, motivo, id))
    conn.commit()
    conn.close()
    return redirect(url_for('agenda.agenda'))