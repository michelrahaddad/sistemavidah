
import logging

logging.basicConfig(
    filename='sistema_medico.log',
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)


import os
from flask import Flask, redirect, url_for
from flask_wtf import CSRFProtect
from routes.auth import auth_bp
from routes.dashboard import dashboard_bp
from routes.receita import receita_bp
from routes.exames_lab import exames_lab_bp
from routes.exames_img import exames_img_bp
from routes.prontuario import prontuario_bp
from routes.agenda import agenda_bp
from routes.medicos import medicos_bp

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'vidah_ecocardiograma_2025')
csrf = CSRFProtect(app)

# Registro dos Blueprints
app.register_blueprint(auth_bp)
app.register_blueprint(dashboard_bp)
app.register_blueprint(receita_bp)
app.register_blueprint(exames_lab_bp)
app.register_blueprint(exames_img_bp)
app.register_blueprint(prontuario_bp)
app.register_blueprint(agenda_bp)
app.register_blueprint(medicos_bp)

@app.route('/')
def index():
    return redirect(url_for('auth.login'))

if __name__ == '__main__':
    app.run()
