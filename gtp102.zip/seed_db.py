
import sqlite3
from werkzeug.security import generate_password_hash

conn = sqlite3.connect('dados.db')
cursor = conn.cursor()

# Inserir médico de teste
crm = 'crm123'
senha_hash = "scrypt:32768:8:1$zdXJ6nXyzWgoUFnA$c2b345a49e918b2c51c140ee035898b3cc64ff3357b6c03d6368dd540dcf6d3e44e8804d075e5642be3f6e1afa375a80c60a07df73d466aa61d6a731f55052ee"
nome = 'Dr. Teste'
cursor.execute("SELECT * FROM medicos WHERE crm = ?", (crm,))
if not cursor.fetchone():
    cursor.execute("INSERT INTO medicos (nome, crm, senha) VALUES (?, ?, ?)", (nome, crm, senha_hash))

# Inserir pacientes
pacientes = ['Maria Silva', 'João Oliveira', 'Ana Costa']
for nome_paciente in pacientes:
    cursor.execute("SELECT * FROM pacientes WHERE nome = ?", (nome_paciente,))
    if not cursor.fetchone():
        cursor.execute("INSERT INTO pacientes (nome) VALUES (?)", (nome_paciente,))

# Inserir agendamento
cursor.execute("SELECT id FROM pacientes WHERE nome = ?", ('Maria Silva',))
paciente = cursor.fetchone()
cursor.execute("SELECT id FROM medicos WHERE crm = ?", ('crm123',))
medico = cursor.fetchone()

if paciente and medico:
    cursor.execute("INSERT INTO agenda (data, paciente, motivo, id_paciente, id_medico) VALUES (?, ?, ?, ?, ?)", (
        '2025-06-02', 'Maria Silva', 'Consulta de rotina', paciente[0], medico[0]
    ))

conn.commit()
conn.close()
print("Dados de teste inseridos com sucesso.")
