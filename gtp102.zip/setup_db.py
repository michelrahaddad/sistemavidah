
import sqlite3

conn = sqlite3.connect('dados.db')
cursor = conn.cursor()

# Criar tabela de médicos
cursor.execute("""
CREATE TABLE IF NOT EXISTS medicos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL,
    crm TEXT NOT NULL UNIQUE,
    senha TEXT NOT NULL
)
""")

# Criar tabela de pacientes
cursor.execute("""
CREATE TABLE IF NOT EXISTS pacientes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome TEXT NOT NULL
)
""")

# Criar tabela de receitas
cursor.execute("""
CREATE TABLE IF NOT EXISTS receitas (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_paciente TEXT,
    medicamentos TEXT,
    posologias TEXT,
    duracoes TEXT,
    vias TEXT,
    medico TEXT,
    data TEXT,
    id_paciente INTEGER,
    id_medico INTEGER
)
""")

# Criar tabela de exames laboratoriais
cursor.execute("""
CREATE TABLE IF NOT EXISTS exames_lab (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_paciente TEXT,
    exames TEXT,
    medico TEXT,
    data TEXT,
    id_paciente INTEGER,
    id_medico INTEGER
)
""")

# Criar tabela de exames de imagem
cursor.execute("""
CREATE TABLE IF NOT EXISTS exames_img (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    nome_paciente TEXT,
    exames TEXT,
    medico TEXT,
    data TEXT,
    id_paciente INTEGER,
    id_medico INTEGER
)
""")

# Criar tabela de agendamentos
cursor.execute("""
CREATE TABLE IF NOT EXISTS agenda (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    data TEXT,
    paciente TEXT,
    motivo TEXT,
    id_paciente INTEGER,
    id_medico INTEGER
)
""")

# Criar tabela de prontuário
cursor.execute("""
CREATE TABLE IF NOT EXISTS prontuario (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    tipo TEXT,
    id_registro INTEGER,
    id_paciente INTEGER,
    id_medico INTEGER,
    data TEXT
)
""")

conn.commit()
conn.close()
print("Todas as tabelas foram criadas com sucesso.")


from werkzeug.security import generate_password_hash
conn = sqlite3.connect('dados.db')
cursor = conn.cursor()
cursor.execute("PRAGMA foreign_keys = ON")

# Inserir médico de teste com hash
try:
    test_nome = "teste"
    test_crm = "crm123"
    test_senha = "senha123"
    senha_hash = generate_password_hash(test_senha)
    cursor.execute("INSERT INTO medicos (nome, crm, senha) VALUES (?, ?, ?)", (test_nome, test_crm, senha_hash))
    print("Médico de teste inserido com senha 'senha123'")
except sqlite3.IntegrityError:
    print("Médico de teste já existe.")

conn.commit()
conn.close()
