# 🩺 Sistema Médico Vidah – Versão Profissional

Sistema 100% funcional com Flask, SQLite, Tailwind CSS, Blueprints e geração de PDF.

---

## 📦 Requisitos

- Python 3.10 ou superior
- `pip` atualizado
- Ambiente virtual (recomendado)

---

## ▶️ Instalação e Execução

```bash
# 1. Crie e ative o ambiente virtual
python -m venv venv
source venv/bin/activate  # Linux/macOS
venv\Scripts\activate   # Windows

# 2. Instale as dependências
pip install -r requirements.txt

# 3. (Opcional) Popular o banco com dados de teste
python setup_db.py
python seed_db.py

# 4. Execute o sistema
python main.py
```

---

## 👨‍⚕️ Usuário de Teste

- Nome: `teste`
- CRM: `crm123`
- Senha: `senha123`

---

## ✅ Testes Manuais Recomendados

1. Login com credenciais de teste
2. Cadastro de um novo médico
3. Emissão de uma receita com múltiplos medicamentos
4. Geração de PDF da receita
5. Solicitação de exames laboratoriais e de imagem
6. Visualização do histórico no prontuário
7. Reemissão de receita/exames pelo prontuário
8. Criação de agendamento na agenda
9. Edição e exclusão de agendamento
10. Logout e tentativa de acesso sem login

---

## 🔒 Segurança e Validações

- Senhas criptografadas com hash
- Sessões protegidas por Flask
- CSRF implementado com Flask-WTF
- Validações visuais com Alpine.js (em todas as telas)
- Validações de campos no backend

---

## 📁 Estrutura de Diretórios

```
sistema_vidah/
├── routes/              # Blueprints (auth, dashboard, exames, etc.)
├── templates/           # HTMLs com Tailwind + macros Jinja
├── static/              # Arquivos CSS, JS e ícones
├── utils/               # Funções auxiliares, conexão DB
├── dados.db             # Banco de dados SQLite
├── main.py              # Execução principal do app
├── setup_db.py          # Criação do banco de dados
├── seed_db.py           # Popula dados de exemplo
├── requirements.txt     # Dependências Python
└── README.md            # Este arquivo
```

---

## 💡 Observações Finais

- Totalmente offline, com plano futuro de backup na nuvem
- Modularizado com Blueprints para fácil manutenção
- Design profissional com Tailwind + ícones modernos
- PDFs incluem assinatura digital e dados do médico