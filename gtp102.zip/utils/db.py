
import sqlite3

def get_db_connection():
    conn = sqlite3.connect('dados.db')
    conn.row_factory = sqlite3.Row
    return conn


from contextlib import contextmanager

@contextmanager
def get_db():
    conn = get_db_connection()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()
