
from flask import Blueprint, render_template, request, session, redirect, url_for
from utils.db import get_db_connection

prontuario_bp = Blueprint('prontuario', __name__)

@prontuario_bp.route('/prontuario', methods=['GET'])
def prontuario():
    if 'usuario' not in session:
        return redirect(url_for('auth.login'))

    filtro_nome = request.args.get('nome')
    filtro_medico = request.args.get('medico')
    filtro_tipo = request.args.get('tipo')
    filtro_data_inicio = request.args.get('data_inicio')
    filtro_data_fim = request.args.get('data_fim')

    conn = get_db_connection()
    filtro_nome = request.args.get('filtro_nome', '').strip()
    filtro_medico = request.args.get('filtro_medico', '').strip()
    query = 'SELECT * FROM prontuario WHERE 1=1'
    params = []
    if filtro_nome:
        query += ' AND nome_paciente LIKE ?'
        params.append(f'%{filtro_nome}%')
    if filtro_medico:
        query += ' AND nome_medico LIKE ?'
        params.append(f'%{filtro_medico}%')
    query += ' ORDER BY data DESC LIMIT 20'
    # prontuarios = conn.execute(query, params).fetchall()

    query = "SELECT * FROM prontuario WHERE 1=1"
    params = []

    if filtro_tipo:
        query += " AND tipo = ?"
        params.append(filtro_tipo)

    if filtro_data_inicio and filtro_data_fim:
        query += " AND date(data) BETWEEN ? AND ?"
        params.append(filtro_data_inicio)
        params.append(filtro_data_fim)

    registros = conn.execute(query, params).fetchall()

    resultados = []
    for reg in registros:
        if reg['tipo'] == 'receita':
            dados = conn.execute("SELECT * FROM receitas WHERE id = ?", (reg['id_registro'],)).fetchone()
        elif reg['tipo'] == 'exame_lab':
            dados = conn.execute("SELECT * FROM exames_lab WHERE id = ?", (reg['id_registro'],)).fetchone()
        elif reg['tipo'] == 'exame_img':
            dados = conn.execute("SELECT * FROM exames_img WHERE id = ?", (reg['id_registro'],)).fetchone()
        else:
            dados = None

        if dados:
            resultados.append({
                'tipo': reg['tipo'],
                'data': reg['data'],
                'id_registro': reg['id_registro'],
                'nome_paciente': dados['nome_paciente'],
                'medico': dados['medico']
            })

    conn.close()
    return render_template('prontuario.html', prontuarios=prontuarios)
    return render_template('prontuario.html', registros=resultados)
